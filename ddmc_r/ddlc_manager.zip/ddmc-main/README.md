# Doki Doki Modding Club
A mod launcher and playtime tracker for Doki Doki Literature Club mods.


For more info, please head to https://lachlanm05.com/ddmc .

Thank you.



and yes, i know it's rough around the edges, but if there any problems lmk.
^ [discord.gg/QWfq3feYnn](https://discord.gg/QWfq3feYnn)    -> #ddmc channel.
